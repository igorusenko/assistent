#!/bin/bash

# Скрипт для развертывания голосового ассистента на VPS
# Использование: bash deploy.sh

set -e

echo "🚀 Начинаем развертывание голосового ассистента..."

# Проверка Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не установлен. Установите Node.js 18+ сначала."
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Требуется Node.js версии 18 или выше. Текущая версия: $(node -v)"
    exit 1
fi

echo "✅ Node.js версия: $(node -v)"

# Установка зависимостей
echo "📦 Устанавливаем зависимости..."
npm install --production

# Проверка .env файла
if [ ! -f .env ]; then
    echo "⚠️  Файл .env не найден. Создайте его на основе .env.example"
    echo "   cp .env.example .env"
    echo "   Затем отредактируйте .env и добавьте ваш OPENAI_API_KEY"
    exit 1
fi

# Создание директории для логов
echo "📁 Создаем директорию для логов..."
mkdir -p logs

# Установка PM2 глобально (если не установлен)
if ! command -v pm2 &> /dev/null; then
    echo "📦 Устанавливаем PM2..."
    npm install -g pm2
fi

# Остановка существующего процесса (если запущен)
echo "🛑 Останавливаем существующий процесс (если запущен)..."
pm2 stop voice-assistant 2>/dev/null || true
pm2 delete voice-assistant 2>/dev/null || true

# Запуск приложения через PM2
echo "▶️  Запускаем приложение через PM2..."
pm2 start ecosystem.config.js

# Сохранение конфигурации PM2 для автозапуска
echo "💾 Настраиваем автозапуск PM2..."
pm2 save
pm2 startup | tail -1 | bash || echo "⚠️  Не удалось настроить автозапуск. Выполните команду вручную."

echo ""
echo "✅ Развертывание завершено!"
echo ""
echo "📊 Полезные команды:"
echo "   pm2 status              - статус приложения"
echo "   pm2 logs voice-assistant - просмотр логов"
echo "   pm2 restart voice-assistant - перезапуск"
echo "   pm2 stop voice-assistant - остановка"
echo ""
echo "🌐 Приложение должно быть доступно на порту 3000"
echo "   Проверьте: curl http://localhost:3000/health"

