# OpenAI Voice Assistant

Голосовой ассистент с прямой интеграцией OpenAI API. Поддерживает распознавание речи (Whisper), генерацию ответов (GPT) и синтез речи (TTS) со стримингом.

## Возможности

- 🎤 **Распознавание речи** через OpenAI Whisper
- 🤖 **Генерация ответов** через GPT-4o-mini со стримингом
- 🔊 **Синтез речи** через OpenAI TTS с streaming отправкой
- 💬 **История разговоров** по sessionId
- ⚡ **Максимальная скорость** - TTS генерируется и отправляется по частям
- 🚀 **Раннее воспроизведение** - аудио начинает играть до завершения генерации

## Установка

1. Установите зависимости:
```bash
npm install
```

2. Создайте файл `.env` или установите переменную окружения:
```env
OPENAI_API_KEY=your-api-key-here
PORT=3000
```

## Запуск

```bash
# Обычный запуск
npm start

# С автоперезагрузкой (для разработки)
npm run dev
```

Сервер будет доступен на `http://localhost:3000`

## Использование

1. Откройте `index.html` в браузере
2. Нажмите кнопку микрофона для начала записи
3. Говорите в микрофон
4. Нажмите кнопку остановки записи
5. Дождитесь ответа ассистента

## API

### POST `/api/voice`

Обрабатывает голосовой запрос и возвращает аудио ответ.

**Запрос:**
- `Content-Type: multipart/form-data`
- Параметры:
  - `file`: аудио файл (WebM, MP3, WAV, M4A и др.)
  - `sessionId`: ID сессии (опционально, для истории разговора)

**Ответ:**
- `Content-Type: audio/mpeg`
- `Transfer-Encoding: chunked`
- Streaming аудио данные (отправляются по частям по мере генерации)

**Пример:**
```javascript
const formData = new FormData();
formData.append('file', audioBlob);
formData.append('sessionId', 'session-123');

const response = await fetch('http://localhost:3000/api/voice', {
    method: 'POST',
    body: formData
});

const audioBlob = await response.blob();
```

### GET `/health`

Проверка работоспособности сервера.

**Ответ:**
```json
{
  "status": "ok",
  "timestamp": "2024-12-01T12:00:00.000Z",
  "openai_configured": true
}
```

## Архитектура

```
Frontend (index.html)
    ↓
Express Server (server.js)
    ↓
OpenAI Whisper (транскрипция)
    ↓
OpenAI GPT-4o-mini (streaming ответ)
    ↓ (по мере получения текста)
OpenAI TTS (синтез по частям)
    ↓ (отправка чанками)
Streaming Audio → Frontend (раннее воспроизведение)
```

### Streaming оптимизация

Для максимальной скорости ответа:
1. GPT streaming отправляет текст по частям
2. Как только накапливается предложение (20+ символов), отправляется на TTS
3. TTS генерирует аудио и сразу отправляется клиенту
4. Frontend начинает воспроизведение при получении ~15KB данных
5. Новые чанки аудио добавляются к уже играющему треку

**Результат:** Время до первого звука сокращается с 3-5 секунд до 1-2 секунд!

## Настройки

### Модели OpenAI

В `server.js` можно изменить:
- **Whisper**: `model: 'whisper-1'` (по умолчанию)
- **GPT**: `model: 'gpt-4o-mini'` (можно изменить на `gpt-4`, `gpt-3.5-turbo` и др.)
- **TTS**: `model: 'tts-1'` (можно использовать `tts-1-hd` для лучшего качества)

### Голос TTS

Доступные голоса: `alloy`, `echo`, `fable`, `onyx`, `nova`, `shimmer`

### История разговоров

История хранится в памяти сервера по `sessionId`. По умолчанию сохраняются последние 10 сообщений.

## Развертывание на VPS

Для развертывания на VPS сервере смотрите подробную инструкцию в файле [DEPLOY.md](./DEPLOY.md).

**Кратко:**
1. Загрузите проект на сервер
2. Установите зависимости: `npm install --production`
3. Создайте `.env` файл с вашим `OPENAI_API_KEY` (см. `env.template`)
4. Запустите через PM2: `pm2 start ecosystem.config.js`
5. Настройте Nginx как reverse proxy (см. `nginx.conf`)

📖 **Подробная инструкция:** [DEPLOY.md](./DEPLOY.md)

## Требования

- Node.js 18+
- OpenAI API ключ
- Современный браузер с поддержкой MediaRecorder API

## Лицензия

MIT

